
/* Tap the creature itself to make it react, without hijacking game controls. */
document.addEventListener('pointerdown',function(e){
  const creature=e.target.closest&&e.target.closest('svg.wv-living-creature');
  if(!creature)return;
  creature.classList.remove('wv-pet-react');
  void creature.getBoundingClientRect();
  creature.classList.add('wv-pet-react');
},{passive:true});
document.addEventListener('animationend',function(e){
  if(e.animationName==='wv-hop'&&e.target.classList.contains('wv-living-body'))
    e.target.closest('svg.wv-living-creature')?.classList.remove('wv-pet-react');
});
