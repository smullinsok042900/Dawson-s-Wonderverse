
/* Keep the chosen creature visible in the swipeable creature strip after each redraw. */
(()=>{let q=0;const fix=()=>{q=0;const st=document.querySelector('.creator-species-strip'),sel=st&&st.querySelector('button.selected');if(sel&&st.scrollLeft===0&&sel.offsetLeft+sel.offsetWidth>st.clientWidth)st.scrollLeft=sel.offsetLeft-(st.clientWidth-sel.offsetWidth)/2};
new MutationObserver(()=>{if(!q)q=requestAnimationFrame(fix)}).observe(document.body,{childList:true,subtree:true})})();
