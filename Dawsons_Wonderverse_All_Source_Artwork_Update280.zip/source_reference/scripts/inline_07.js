
/* Update 268: original pet-care mini-loop; no Fluvsies assets or mechanics copied.
   Separate versioned save namespace; never modifies the main game save schema. */
(()=>{
'use strict';
const KEY='dawson-wonderverse-petcare-v1';
const clamp=n=>Math.max(0,Math.min(100,Math.round(n)));
let records={};
try{const parsed=JSON.parse(localStorage.getItem(KEY)||'{}');if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed))records=parsed}catch(e){}
let modal=null,activeId='',current=null,sleeping=false;
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(records))}catch(e){}};
function getPet(){
 const snapshot=typeof window.wvSnapshot==='function'?window.wvSnapshot():null;
 if(!snapshot||!Array.isArray(snapshot.creatures))return null;
 return snapshot.creatures.find(c=>c.id===snapshot.active)||snapshot.creatures[0]||null;
}
function record(id){
 const p=records[id]||{food:75,clean:75,energy:75,love:75,last:Date.now(),stars:0};
 const elapsed=Math.max(0,Math.min(48,(Date.now()-Number(p.last||Date.now()))/3600000));
 p.food=clamp(Number(p.food??75)-elapsed*2);
 p.clean=clamp(Number(p.clean??75)-elapsed*.9);
 p.energy=clamp(Number(p.energy??75)-elapsed*1.4);
 p.love=clamp(Number(p.love??75)-elapsed*.7);
 p.last=Date.now();p.stars=Number(p.stars||0);
 records[id]=p;save();return p;
}
function showMeters(){
 if(!modal||!current)return;
 const p=records[activeId];
 for(const k of ['food','clean','energy','love']){
  const bar=modal.querySelector('[data-meter="'+k+'"]');
  if(bar){bar.value=p[k];modal.querySelector('[data-value="'+k+'"]').textContent=p[k]}
 }
 modal.querySelector('#nurseryStars').textContent='★ '+p.stars;
}
function action(kind){
 if(!current||sleeping)return;
 const p=records[activeId],msg=modal.querySelector('.nursery-message');
 const changes={
  feed:{food:25,clean:-3,energy:3,love:3},
  wash:{clean:30,energy:-3,love:4},
  play:{love:23,food:-7,clean:-5,energy:-10},
  sleep:{energy:32,food:-4,clean:0,love:3}
 };
 const effect=changes[kind];if(!effect)return;
 Object.entries(effect).forEach(([key,amount])=>p[key]=clamp(p[key]+amount));
 p.stars+=1;p.last=Date.now();save();showMeters();
 const phrases={feed:'Yum! A delicious snack!',wash:'Splish splash! All clean!',play:'Yay! Let’s play again!',sleep:'Sweet dreams, little friend!'};
 msg.textContent=phrases[kind];
 const box=modal.querySelector('.nursery-pet');
 box.classList.remove('nursery-joy','nursery-sleep');void box.offsetWidth;
 box.classList.add(kind==='sleep'?'nursery-sleep':'nursery-joy');
 const fx=document.createElement('span');fx.className='nursery-sparkle';fx.textContent={feed:'🍓',wash:'🫧',play:'💗',sleep:'💤'}[kind];box.appendChild(fx);
 setTimeout(()=>fx.remove(),1100);
 if(kind==='sleep'){sleeping=true;modal.querySelectorAll('.nursery-actions button').forEach(b=>b.disabled=true);setTimeout(()=>{sleeping=false;box.classList.remove('nursery-sleep');if(modal)modal.querySelectorAll('.nursery-actions button').forEach(b=>b.disabled=false)},2400)}
}
function open(){
 if(modal)return;
 current=getPet();
 if(!current){alert('Make your first magical friend in the Creature Creator, then come back to care for it!');return}
 activeId=String(current.id);record(activeId);
 const name=String(current.name||'Your magical friend').slice(0,48);
 const m=document.createElement('div');m.id='wvNursery';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-label','Care for your creature');
 m.innerHTML=`<div class="nursery-card"><div class="nursery-head"><h2>♡ ${name.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}'s Cozy Care</h2><span id="nurseryStars">★ 0</span><button type="button" class="nursery-close">Close</button></div><div class="nursery-layout"><div class="nursery-pet" id="nurseryPet"></div><div><div class="nursery-meters">${[['food','Hungry'],['clean','Clean'],['energy','Rested'],['love','Happy']].map(([key,label])=>`<label class="nursery-meter"><span>${label}</span><progress data-meter="${key}" max="100" value="75"></progress><span data-value="${key}">75</span></label>`).join('')}</div><div class="nursery-actions"><button type="button" data-care="feed">🍓 Feed</button><button type="button" data-care="wash">🫧 Bath</button><button type="button" data-care="play">🧸 Play</button><button type="button" data-care="sleep">💤 Nap</button></div><p class="nursery-message" role="status">Take care of your magical friend!</p></div></div></div>`;
 modal=m;
 // Render with the game's existing creature renderer; do not replace artwork.
 try{m.querySelector('#nurseryPet').innerHTML=window.WonderverseSprites.renderCreature(current,'nursery'+Date.now())}catch(e){m.querySelector('#nurseryPet').textContent='♡'}
 const close=()=>{modal=null;sleeping=false;m.remove();document.removeEventListener('keydown',key)};
 const key=e=>{if(e.key==='Escape')close()};
 m.querySelector('.nursery-close').addEventListener('click',close);
 m.addEventListener('click',e=>{if(e.target===m)close();const b=e.target.closest('[data-care]');if(b)action(b.dataset.care)});
 document.addEventListener('keydown',key);document.body.appendChild(m);showMeters();
}
const btn=document.createElement('button');btn.id='wvNurseryOpen';btn.type='button';btn.textContent='♡ Care for Pet';btn.setAttribute('aria-label','Care for your magical creature');btn.addEventListener('click',open);document.body.appendChild(btn);
})();
