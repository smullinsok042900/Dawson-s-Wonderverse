
/* Update 262: portable, validated save backup; no changes to the existing save schema. */
(()=>{
 'use strict';
 const KEY='dawson-wonderverse-magicfriends-v1';
 const BACKUP=KEY+'-recovery';
 const MAX=1048576;
 function valid(raw){
  if(typeof raw!=='string'||raw.length>MAX)return false;
  try{const p=JSON.parse(raw);return p&&p.v===1&&Array.isArray(p.creatures)&&p.creatures.length<=6&&Array.isArray(p.plots)&&p.plots.length===4&&p.dino&&typeof p.dino==='object'&&p.house&&typeof p.house==='object'}catch(e){return false}
 }
 function open(){
  if(document.getElementById('wvBackupDialog'))return;
  const modal=document.createElement('div');modal.id='wvBackupDialog';modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-label','Save backup');
  modal.innerHTML='<div class="wvbackupcard"><h2>Save your Wonderverse</h2><p>Back up Dawson’s creatures and progress before switching phones or websites. Backups stay on your device unless you share them.</p><div class="wvbackupactions"><button type="button" id="wvExport">Save backup file</button><label for="wvImport">Restore from file<input id="wvImport" type="file" accept=".json,application/json"></label><button type="button" class="wvbackupclose" id="wvBackupClose">Close</button></div><p id="wvBackupMessage" role="status" aria-live="polite"></p></div>';
  const status=()=>modal.querySelector('#wvBackupMessage');
  const close=()=>{modal.remove();document.removeEventListener('keydown',onKey)};
  const onKey=e=>{if(e.key==='Escape')close()};
  modal.addEventListener('click',e=>{if(e.target===modal)close()});
  modal.querySelector('#wvBackupClose').addEventListener('click',close);
  modal.querySelector('#wvExport').addEventListener('click',()=>{
   try{
    const raw=localStorage.getItem(KEY)||localStorage.getItem(BACKUP);
    if(!valid(raw)){status().textContent='No valid saved game found yet. Create or save a creature first.';return}
    const blob=new Blob([raw],{type:'application/json'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Dawsons_Wonderverse_Save.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
    status().textContent='Backup prepared. Save the downloaded file in Files.';
   }catch(e){status().textContent='Could not export. Check that browser storage is available.'}
  });
  modal.querySelector('#wvImport').addEventListener('change',async e=>{
   const file=e.target.files&&e.target.files[0];if(!file)return;
   if(file.size>MAX){status().textContent='That backup file is too large.';return}
   try{
    const raw=await file.text();
    if(!valid(raw)){status().textContent='Invalid or incompatible backup. Nothing was changed.';return}
    if(!confirm('Restore this backup? This will replace your current saved progress on this device.')){status().textContent='Restore cancelled. Your game was not changed.';return}
    const existing=localStorage.getItem(KEY);
    if(valid(existing))localStorage.setItem(BACKUP,existing);
    localStorage.setItem(KEY,raw);
    status().textContent='Backup restored. Reloading your saved game…';
    setTimeout(()=>location.reload(),450);
   }catch(err){status().textContent='Could not read this file. Your game was not changed.'}
  });
  document.body.appendChild(modal);document.addEventListener('keydown',onKey);modal.querySelector('#wvExport').focus();
 }
 const btn=document.createElement('button');btn.id='wvBackupBtn';btn.type='button';btn.textContent='💾';btn.title='Back up or restore saved game';btn.setAttribute('aria-label','Back up or restore saved game');btn.addEventListener('click',open);document.body.appendChild(btn);
})();
