
(()=>{const W=1672,H=941,home=document.getElementById("wvHome"),stage=document.getElementById("wvStage"),toast=document.getElementById("wvToast");
let last="create",tt;
const soon=(n)=>({msg:n,sub:"Coming soon"});
/* z = [left, top, right, bottom] in artwork pixels. tab = open that world; click = press an existing game button. */
const Z=[
{n:"Profile",z:[10,18,365,150],msg:"Dawson · Level 5",sub:"Profile coming soon"},
{n:"Stars",z:[1120,20,1335,85],msg:"Star counter",sub:"Coming soon"},
{n:"Gems",z:[1345,20,1555,85],msg:"Gem counter",sub:"Coming soon"},
{n:"Settings",z:[1570,15,1658,100],click:"parentBtn"},
{n:"Princess Castle",z:[420,50,655,280],tab:"princess"},
{n:"Wonder House",z:[190,150,480,432],tab:"house"},
{n:"Creature Creator",z:[10,436,480,705],tab:"create"},
{n:"Magic Garden",z:[600,320,930,572],tab:"garden"},
{n:"Dinosaur Cove",z:[1150,100,1500,312],tab:"dino"},
{n:"Pirate Beach",z:[1310,300,1652,525],tab:"pirate"},
{n:"Art Studio & Workshop",z:[1060,450,1495,712],...soon("Art Studio & Workshop")},
{n:"Play",z:[615,765,1055,915],play:1},
{n:"Inventory",z:[62,768,218,918],...soon("Inventory")},
{n:"My Pets",z:[238,768,388,918],tab:"friends"},
{n:"Collection",z:[408,768,558,918],click:"passportBtn"},
{n:"World Map",z:[1118,768,1272,918],msg:"You’re on the world map!",sub:"Tap any place to visit"},
{n:"Achievements",z:[1288,768,1442,918],ach:1},
{n:"Daily Fun",z:[1462,768,1618,918],...soon("Daily Fun")},
{n:"Pet",z:[360,548,625,790],msg:"✨ Hi, Dawson! ✨",sub:"Your fairy kitten loves you",pet:1}
];
function say(m,s){toast.innerHTML=m+(s?"<small>"+s+"</small>":"");toast.classList.add("on");clearTimeout(tt);tt=setTimeout(()=>toast.classList.remove("on"),2200)}
function sparkle(el){const r=stage.getBoundingClientRect(),b=el.getBoundingClientRect();for(let i=0;i<9;i++){const s=document.createElement("div");s.className="wvspark";s.textContent=["✨","💖","⭐","🦋"][i%4];s.style.left=(b.left-r.left+b.width/2)+"px";s.style.top=(b.top-r.top+b.height/2)+"px";s.style.setProperty("--dx",(Math.random()*160-80)+"px");s.style.setProperty("--dy",(-40-Math.random()*120)+"px");stage.appendChild(s);setTimeout(()=>s.remove(),1000)}}
function enter(t){last=t;home.classList.add("off");window.wvGo(t)}
const ACH=[
["🐾","First Friend","Make your first creature",s=>s.creatures.length>=1],
["🦄","Pet Collector","Have 3 creatures",s=>s.creatures.length>=3],
["🌱","Green Thumb","Grow something in the Magic Garden",s=>s.plots.some(p=>p.stage>0)||s.flowers>0],
["💐","Bouquet Maker","Make a flower bouquet",s=>(s.bouquets||0)>0],
["🥚","Dino Hatcher","Hatch a dinosaur egg",s=>s.dino.hatched.some(Boolean)],
["🦖","Dino Trio","Hatch all 3 dinosaurs",s=>s.dino.hatched.length===3&&s.dino.hatched.every(Boolean)],
["🦴","Fossil Finder","Find a fossil",s=>s.dino.fossils.some(Boolean)],
["💎","Royal Gem","Find a castle gem",s=>s.princess.gems.some(Boolean)],
["👑","Crown Winner","Earn a crown",s=>s.princess.crowns>0],
["🏴‍☠️","Treasure Hunter","Find pirate treasure",s=>s.pirate.found.some(Boolean)||s.pirate.treasures>0],
["🏠","Cozy Home","Visit your Wonder House",s=>s.house.visits>0]];
function showAch(){let s={creatures:[],plots:[],flowers:0,dino:{hatched:[],fossils:[]},princess:{gems:[],crowns:0},pirate:{found:[],treasures:0},house:{visits:0}};
try{if(typeof window.wvSnapshot==='function')s=window.wvSnapshot()}catch(e){}
const got=ACH.map(a=>{try{return !!a[3](s)}catch(e){return false}}),n=got.filter(Boolean).length;
const m=document.createElement("div");m.id="wvAch";m.setAttribute("role","dialog");m.setAttribute("aria-label","Achievements");
m.innerHTML=`<div class="wvcard"><h2>🏆 Achievements</h2><p>${n} of ${ACH.length} trophies</p><div class="wvgrid">${ACH.map((a,i)=>`<div class="wvtro ${got[i]?"yes":"no"}"><span>${got[i]?a[0]:"🔒"}</span><b>${a[1]}</b><small>${a[2]}</small></div>`).join("")}</div><button type="button" class="wvclose">Close</button></div>`;
const close=()=>{m.remove();document.removeEventListener("keydown",esc)},esc=e=>{if(e.key==="Escape")close()};
m.onclick=e=>{if(e.target===m||e.target.classList.contains("wvclose"))close()};document.addEventListener("keydown",esc);home.appendChild(m);m.querySelector(".wvclose").focus()}
Z.forEach(o=>{const b=document.createElement("button");b.type="button";b.className="wvhs";b.setAttribute("aria-label",o.n);const[x1,y1,x2,y2]=o.z;
b.style.cssText=`left:${x1/W*100}%;top:${y1/H*100}%;width:${(x2-x1)/W*100}%;height:${(y2-y1)/H*100}%`;
b.onclick=()=>{b.classList.add("tap");setTimeout(()=>b.classList.remove("tap"),200);
if(o.tab)return enter(o.tab);
if(o.play)return enter(last);
if(o.ach)return showAch();
if(o.click){home.classList.add("off");window.wvGo(last);setTimeout(()=>document.getElementById(o.click).click(),50);return}
say(o.msg,o.sub);if(o.pet)sparkle(b)};
stage.appendChild(b)});
// Accessible visible fallback to enter the game, independent of image-map hotspots.
const launch=document.createElement('button');launch.type='button';launch.id='wvLaunch';launch.textContent='▶ Play Wonderverse';launch.setAttribute('aria-label','Play Dawson’s Wonderverse');launch.style.cssText='position:absolute;z-index:30;left:50%;bottom:3%;transform:translateX(-50%);border:3px solid white;border-radius:22px;padding:10px 20px;min-height:48px;background:linear-gradient(#ffde86,#ff9dc6);color:#59316d;font-weight:900;font-size:clamp(13px,2vw,19px);box-shadow:0 4px 0 #9d5a91;touch-action:manipulation;cursor:pointer;white-space:nowrap';launch.addEventListener('click',()=>enter(last));stage.appendChild(launch);
document.getElementById("wvMapBtn").onclick=()=>home.classList.remove("off");
document.getElementById("wvDbg").onclick=e=>{const on=home.classList.toggle("debug");e.target.textContent=on?"Hide tap zones":"Show tap zones"};
})();
