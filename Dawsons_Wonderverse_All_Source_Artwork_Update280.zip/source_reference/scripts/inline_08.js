
(function(){
 document.addEventListener('pointerup',function(ev){
  const preview=ev.target.closest&&ev.target.closest('#previewCreature');
  if(!preview)return;
  preview.classList.remove('wv273-cheer');
  void preview.offsetWidth;
  preview.classList.add('wv273-cheer');
 },{passive:true});
 document.addEventListener('animationend',function(ev){
  if(ev.animationName==='wv273-cheer'){
   const preview=ev.target.closest&&ev.target.closest('#previewCreature');
   if(preview)preview.classList.remove('wv273-cheer');
  }
 });
})();
