
/* World movement: persistent across scene re-renders without altering save schema.
   Buttons are intentionally separate from game activities; no timer or credit usage. */
(()=>{
 const eligible=new Set(['garden','house','friends','dino','princess','pirate']);
 let current=null, held=new Set(), x=.5, y=.47, dest=null, last=0, jumping=false, petting=false, idleAt=0, idleTimer=0;
 function sceneName(scene){return scene?.dataset.scene||''}
 function setup(){
  const scene=document.querySelector('main .scene')||document.querySelector('.scene');
  const name=sceneName(scene);
  if(!scene||!eligible.has(name)){current=null;held.clear();return}
  if(current?.scene===scene)return;
  held.clear();dest=null;x=.5;y=.47;
  let player=scene.querySelector('#liveCreature');
  if(!player){
   const data=window.wvRenderActiveCreature?.();
   if(!data){current=null;return}
   player=document.createElement('div');player.id='liveCreature';player.className='creature-wrap live';
   player.style.cssText='position:absolute;width:clamp(110px,23%,230px);left:30.5%;top:29%;z-index:7';
   player.innerHTML=data.svg+'<div class="namebadge"></div>';
   player.querySelector('.namebadge').textContent=data.name;
   scene.appendChild(player);
  }
  scene.classList.add('wv-playground');player.classList.add('wv-player');
  const pad=document.createElement('div');pad.className='wv-move-pad';pad.setAttribute('aria-label','Move your creature');
  pad.innerHTML='<button type="button" data-move="left" aria-label="Walk left">◀</button><button type="button" data-move="right" aria-label="Walk right">▶</button><button type="button" class="wv-jump-button" data-move="jump" aria-label="Jump">Jump</button><button type="button" class="wv-pet-button" data-move="pet" aria-label="Pet your creature">♡ Pet</button><button type="button" class="wv-run-button" data-move="run" aria-label="Run">Run</button>';
  scene.appendChild(pad);
  for(const btn of pad.querySelectorAll('button')){
   const action=btn.dataset.move;
   btn.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();btn.setPointerCapture(e.pointerId);if(action==='jump')hop();else if(action==='pet')pet();else{held.add(action);dest=null;btn.classList.add('wv-pressed')} });
   for(const evt of ['pointerup','pointercancel','lostpointercapture'])btn.addEventListener(evt,()=>{held.delete(action);btn.classList.remove('wv-pressed')});
  }
  player.addEventListener('pointerdown',e=>{e.stopPropagation();pet()});
  scene.addEventListener('pointerdown',e=>{
   if(e.target.closest('button,[data-plot],[data-act],[data-house],.wv-move-pad,.creature-wrap,.house-object,.planter,.egg,.berry,#wateringCan'))return;
   const r=scene.getBoundingClientRect();if(!r.width||!r.height)return;
   dest={x:Math.max(.12,Math.min(.88,(e.clientX-r.left)/r.width)),y:Math.max(.25,Math.min(.68,(e.clientY-r.top)/r.height))};
  });
  current={scene,player,name};idleAt=performance.now();place();
 }
 function place(){if(!current)return;const p=current.player;p.style.left=(x*100-19.5)+'%';p.style.top=(y*100-16)+'%';}
 function pet(){if(!current)return;const p=current.player;p.classList.remove('wv-petted');void p.offsetWidth;p.classList.add('wv-petted');setTimeout(()=>p.classList.remove('wv-petted'),850);const h=document.createElement('span');h.className='wv-heart-pop';h.textContent='♥';p.appendChild(h);setTimeout(()=>h.remove(),950)}
 function hop(){if(!current||jumping)return;jumping=true;const p=current.player;p.classList.remove('wv-jumping');void p.offsetWidth;p.classList.add('wv-jumping');setTimeout(()=>{p.classList.remove('wv-jumping');jumping=false},580)}
 function tick(now){
  if(!current||!current.scene.isConnected||!current.player.isConnected||document.querySelector('main .scene')!==current.scene)setup();
  if(current){
   const dt=Math.min(.05,(now-(last||now))/1000);let dx=0,dy=0;
   if(held.has('left'))dx=-1;if(held.has('right'))dx=1;
   if(!dx&&dest){const vx=dest.x-x,vy=dest.y-y;if(Math.hypot(vx,vy)>.025){dx=Math.sign(vx);dy=Math.sign(vy)*.35}else dest=null}
   const moving=!!dx;const running=held.has('run');if(moving)idleAt=now;
   x=Math.max(.12,Math.min(.88,x+dx*dt*(running?.47:.28)));y=Math.max(.25,Math.min(.68,y+dy*dt*.17));
   current.player.classList.toggle('wv-walking',moving);current.player.classList.toggle('wv-running',moving&&running);current.player.classList.toggle('wv-looking',!moving&&now-idleAt>3500&&Math.sin(now/1400)>0.35);
   if(moving)current.player.classList.toggle('wv-facing-left',dx<0);
   if(moving)place();
  }
  last=now;requestAnimationFrame(tick);
 }
 document.addEventListener('keydown',e=>{if(/INPUT|TEXTAREA/.test(document.activeElement?.tagName||''))return;if(e.key==='ArrowLeft'||e.key==='ArrowRight'){held.add(e.key==='ArrowLeft'?'left':'right');dest=null;}if(e.key===' '&&current){e.preventDefault();hop()}});
 document.addEventListener('keyup',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight')held.delete(e.key==='ArrowLeft'?'left':'right')});
 new MutationObserver(()=>{if(!current||!current.scene.isConnected)setup()}).observe(document.body,{childList:true,subtree:true});
 setup();requestAnimationFrame(tick);
})();
