# Dawson's Wonderverse — Complete Source and Artwork (Update 280)

## Run
Open `index.html` in a modern browser, or upload it to static hosting. This is the **latest available Update 280** HTML checkpoint. It is self-contained with embedded scripts, styles and image assets.

## Contents
- `index.html`: complete existing game HTML, CSS, JavaScript, and embedded assets (unchanged from Update 280).
- `source_reference/scripts/`: extracted copies of the 8 inline JavaScript blocks, for review/editing.
- `source_reference/styles/`: extracted copies of the 16 inline CSS blocks, for review/editing.
- `artwork/`: 26 images extracted from the earlier Update 279 bundle, for easier asset access. These are reference/export copies; the playable HTML already embeds its own assets.
- `README_Update279.md`: previous checkpoint notes.

## Important
Editing `source_reference` files **does not change** `index.html` automatically. The original app is monolithic and these are reference exports, not a working multi-file build pipeline. Preserve the HTML and saved-data keys when refactoring. User-specific browser localStorage save data is not included in the ZIP.

## Known unfinished features
The creature artwork is still largely flattened; independent limb/wing articulation, precise anatomical color regions and some customization behavior remain incomplete. Browser/iPhone interaction testing is not certified by this packaging step.

## Integrity
The playable `index.html` is byte-identical to the supplied Update 280 HTML checkpoint.
