# Dawson’s Wonderverse Update 279 — Creature Creator repair
Source: Update 278 Safe Mood Animation, with same storage key and original 19 illustrated species.

- Repaired legacy CSS that hid many creator category buttons and color controls.
- Made the species selector, categories and choices horizontally swipeable with minimum touch sizes.
- Made the creator control panel vertically scrollable and the primary working controls sticky.
- Prioritized actually working Dress up, whole-image Color, Mood, and Species choices.
- Explicitly identifies anatomical settings as saved preferences only, not falsely implemented illustration edits.
- Removed dormant code generating extra fake wings, horns and tails; existing CSS also hides stale overlays.
- Kept all five world destinations, saved state, and existing images.

Checks: Node syntax for all inline scripts, static regression assertions, ZIP integrity. Browser check is separate; no iPhone Safari verification.
Known limitations: flat illustrations have no independently articulated limbs; color is whole-image tint; additional anatomical options are stored but cannot change image anatomy.
